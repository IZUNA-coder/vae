package Modele;

/**
 * EnchereTropFaibleException
 */
public class EnchereTropFaibleException extends Exception {

    
}