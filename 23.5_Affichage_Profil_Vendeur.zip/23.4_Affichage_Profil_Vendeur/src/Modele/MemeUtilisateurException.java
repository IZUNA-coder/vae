package Modele;

public class MemeUtilisateurException extends Exception{
    
}
